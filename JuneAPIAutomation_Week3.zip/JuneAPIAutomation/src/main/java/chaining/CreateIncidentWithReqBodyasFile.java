package chaining;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithReqBodyasFile extends BaseAPISteps {
	
	@Test
	public void createIncident() {	
		File inputFile = new File("./src/main/resources/CreateIncident_request.json");
		// auth, queryparams, headers, requestbody
		RequestSpecification inputRequest = RestAssured
				.given()
				.log()
				.all()
				.queryParam("sysparm_fields", "sys_id, category, number, short_description, description")
				.contentType(ContentType.JSON)
				.accept(ContentType.XML)
				.body(inputFile);
		
		response = inputRequest.when().post();
		response.then().log().all();
		//String sys_id = response.body().jsonPath().get("result.sys_id");
		sys_id = response.body().xmlPath().get("response.result.sys_id");
		System.out.println("Sys_id retrived from the response: "+sys_id);		
	}

}
