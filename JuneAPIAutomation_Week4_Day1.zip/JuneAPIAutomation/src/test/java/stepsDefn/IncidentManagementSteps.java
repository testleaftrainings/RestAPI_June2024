package stepsDefn;

import org.hamcrest.Matchers;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IncidentManagementSteps {
	
	RequestSpecification inputRequest;
	Response response;
	
	@Given("Set the endpoint for incident management API")
	public void setEndPOint() {
		RestAssured.baseURI = "https://dev196137.service-now.com/api/now/table/incident";
	}
	
	@Given("Set the user credentials for authenticating the system")
	public void setAuth() {
		inputRequest = RestAssured
		.given()
		.auth()
		.basic("admin", "wL39b$PaJ$oN"); 
	}
	
	@Given("Set the queryparameter in the input request")
	public void setQueryParam() {
		inputRequest.queryParam("sysparm_fields", "sys_id, category, number");
	}
	
	@Given("Set the contentType for the input request")
	public void setContentType() {
		inputRequest.contentType(ContentType.JSON);
	}
	
	@When("User send POST request to Incident management API")
	public void sendRequest() {
		response = inputRequest.when().post();
		response.prettyPrint();
	}
	
	@Then("Validate the status code is {int}")
	public void validateStatusCode(Integer statusCode) {
		response.then().assertThat().statusCode(Matchers.equalTo(statusCode));
	}

}
