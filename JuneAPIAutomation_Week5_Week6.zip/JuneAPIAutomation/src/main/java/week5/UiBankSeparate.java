package week5;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UiBankSeparate {

	public static void main(String[] args) {
		
		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/accounts";
		
		RestAssured.authentication = RestAssured.oauth2("7m25gTXA9MFXeNVcN7CKTlnXUS9Zpnumib5p4vkqMH13ItzFjozim6NXrzdXVVfj");
		
		Response response = RestAssured
		.given()
		.log()
		.all()
		.contentType(ContentType.JSON)
		.body("{\r\n"
				+ "    \"friendlyName\": \"TestForJuly123\",\r\n"
				+ "    \"type\": \"savings\",\r\n"
				+ "    \"userId\": \"64290731ba9f8a0047adacfc\",\r\n"
				+ "    \"balance\": 100,\r\n"
				+ "    \"accountNumber\": 40520764\r\n"
				+ "}")
		.post();
		
		response.then().log().all();

	}

}
