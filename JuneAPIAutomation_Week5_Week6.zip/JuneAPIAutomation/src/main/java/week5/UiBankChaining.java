package week5;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

public class UiBankChaining {
	
	String accessToken;
	String userID;
	
	@Test
	public void login() {
		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/users/login";
		Response response = RestAssured
				.given()
				.log()
				.all()
				.contentType(ContentType.JSON)
				.body(
						"{\r\n"
				+ "    \"username\": \"FebApiuser\",\r\n"
				+ "    \"password\": \"Eagle@123\"\r\n"
				+ "}")
		.post();
		
		ValidatableResponse validatableResponse = response.then().log().all();
		validatableResponse.assertThat().statusCode(Matchers.equalTo(200));
		accessToken = response.body().jsonPath().getString("id");
		userID = response.body().jsonPath().getString("userId");
	}
	
	@Test(dependsOnMethods = "week5.UiBankChaining.login")
	public void createAccount() {
		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/accounts";
		Response response = RestAssured
				.given()
				.auth()
				.oauth2(accessToken)
				.log()
				.all()
				.contentType(ContentType.JSON)
				.body(
						"{\r\n"
						+ "    \"friendlyName\": \"HelloAPITest\",\r\n"
						+ "    \"type\": \"checking\",\r\n"
						+ "    \"userId\": \""+userID+"\",\r\n"
						+ "    \"balance\": 100,\r\n"
						+ "    \"accountNumber\": 35062454\r\n"
						+ "}")
		.post();
		ValidatableResponse validatableResponse = response.then().log().all();
		validatableResponse.assertThat().statusCode(Matchers.equalTo(200));
	}

}
