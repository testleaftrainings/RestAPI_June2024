package week5;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

public class LoginUIBank {
	
	@Test
	public void login() {
		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/users/login";
		Response response = RestAssured
				.given()
				.log()
				.all()
				.contentType(ContentType.JSON)
				.body(
						"{\r\n"
				+ "    \"username\": \"FebApiuser\",\r\n"
				+ "    \"password\": \"Eagle@123\"\r\n"
				+ "}")
		.post();
		
		ValidatableResponse validatableResponse = response.then().log().all();
		validatableResponse.assertThat().statusCode(Matchers.equalTo(200));
	}
	
	@Test
	public void createAccount() {
		RestAssured.baseURI = "https://uibank-api.azurewebsites.net/api/accounts";
		Response response = RestAssured
				.given()
				.auth()
				.oauth2("bjnLprAlCuhWrf9yxbajYjAWNbvOFu5rmimVW9Ew7qUf7MwEL55SzfuqqT8hFWwC")
				.log()
				.all()
				.contentType(ContentType.JSON)
				.body(
						"{\r\n"
						+ "    \"friendlyName\": \"HelloAPITest\",\r\n"
						+ "    \"type\": \"checking\",\r\n"
						+ "    \"userId\": \"64290731ba9f8a0047adacfc\",\r\n"
						+ "    \"balance\": 100,\r\n"
						+ "    \"accountNumber\": 35062454\r\n"
						+ "}")
		.post();
		ValidatableResponse validatableResponse = response.then().log().all();
		validatableResponse.assertThat().statusCode(Matchers.equalTo(200));
	}

}
