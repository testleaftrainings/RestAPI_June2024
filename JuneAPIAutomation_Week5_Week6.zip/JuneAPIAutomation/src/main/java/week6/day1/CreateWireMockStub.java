package week6.day1;

import java.io.File;

import org.testng.annotations.Test;

import com.github.tomakehurst.wiremock.client.WireMock;
import com.networknt.schema.JsonSchemaIdValidator;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateWireMockStub {
	
	//@Test
	public void createStubForServiceNow() {
		WireMock.stubFor(
				WireMock
				.post("/api/now/table/incident")
				.willReturn(
						WireMock.aResponse()
				.withStatus(201)
				.withBody("{\r\n"
						+ "    \"result\": {\r\n"
						+ "        \"sys_id\": \"4f4163f0832f421088b9f5a6feaad371\",\r\n"
						+ "        \"number\": \"INC0010105\",\r\n"
						+ "        \"short_description\": \"Created from restassured\",\r\n"
						+ "        \"description\": \"Sending the request body as string\",\r\n"
						+ "        \"category\": \"inquiry\"\r\n"
						+ "    }\r\n"
						+ "}"))
				);
	}
	
	
	@Test
	public void createIncident() {
		RestAssured.baseURI = "http://localhost/api/now/table/incident";
		
		// auth, queryparams, headers, requestbody
		RequestSpecification inputRequest = RestAssured
				.given()
				/*
				 * .auth() .basic("admin", "wL39b$PaJ$oN")
				 */
				.contentType(ContentType.JSON)
				.accept(ContentType.JSON)
				.body("{\r\n" + "    \"short_description\": \"Created from restassured\",\r\n"
						+ "    \"description\": \"Sending the request body as string\"\r\n" + "}");

		
		Response response = inputRequest.when().post();
		//c6907bb0836f421088b9f5a6feaad34f
		//c6907bb0836f421088b9f5a6feaad34f
		response.prettyPrint();
		System.out.println(response.statusCode());
		response.then().assertThat().body(JsonSchemaValidator
				.matchesJsonSchema(new File("./src/main/resources/Createresponse-Schema.json")));
	}

}
